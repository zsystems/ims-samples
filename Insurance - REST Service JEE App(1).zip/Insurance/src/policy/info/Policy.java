package policy.info;

public class Policy {
	private int policyNumber;
	
	public int getPolicyNumber() {
		return policyNumber;
	}
	
	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}
}
